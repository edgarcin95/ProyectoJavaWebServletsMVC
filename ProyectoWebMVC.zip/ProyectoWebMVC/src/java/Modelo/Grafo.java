/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Util.GraphPicture;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import javax.swing.JFrame;

/**
 *
 * @author edgar
 */
public class Grafo {
    private String name;
    private int V; //No. de vertices
    private int edges; //No. de aristas
    private LinkedList<Integer> adj[]; //Para la lista de adyacencias
    private int[][] matrix; //Matriz de adyacencias
    private boolean[][] isSetMatrix; //Ayuda a añadir grafos en la clase
    int cycle[];

    public Grafo(String name, int vertices, int aristas) {
        this.name = name;
        this.V = vertices;
        this.edges = aristas;
        adj = new LinkedList[vertices];
        for (int i = 0; i < vertices; ++i)
            adj[i] = new LinkedList();
        matrix = new int[vertices][vertices];
        isSetMatrix = new boolean[vertices][vertices];
    }

    public String getName() {
        return name;
    }

    public int getV() {
        return V;
    }

    public int getEdges() {
        return edges;
    }

    public LinkedList<Integer>[] getAdj() {
        return adj;
    }

    public int[][] getMatrix() {
        return matrix;
    }
    
    //Función para añadir una arista al grafo
    public void addEdge(int v, int w){ 
        adj[v].add(w); //Agrega w a la lista v
        int valueToAdd = 1;
        matrix[v][w] = valueToAdd; //Agrega un 1 a la matriz de adyacencias en (v,w)
        isSetMatrix[v][w] = true;
        matrix[w][v] = valueToAdd; //Agrega un 1 a la matriz en (w,v)
        isSetMatrix[w][v] = true;
    }
    
    public void printMatrix() {
        System.out.println("Matriz de adyaciencias:");
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                //Se imprime 1 en donde se marcó, los demás imprime 0
                if (isSetMatrix[i][j])
                    System.out.format("%8s", String.valueOf(matrix[i][j]));
                else System.out.format("%8s", "0");
            }
            System.out.println();
        }
    }
    
    ArrayList<Integer> visitaDFS(int v, boolean visited[], ArrayList<Integer> ret){
        //Marca el vértice actual como visitado y lo imprime
        visited[v] = true;
        ret.add(v);
        //Recorre por todos los vertices adyacentes al vértice actual
        Iterator<Integer> i = adj[v].listIterator();
        while (i.hasNext()) 
        {
            int n = i.next();
            if (!visited[n])
                visitaDFS(n, visited, ret);
        }
        //Devuelve la lista de vértices en el orden en el que son visitados
        return ret;
    }
    
    public ArrayList<Integer> DFS(int v){
        ArrayList<Integer> dfs = new ArrayList<Integer>();
        //Marca todos los vértices como no visitados (JAVA pone 'false' por default)
        boolean visited[] = new boolean[V];
        return visitaDFS(v, visited, dfs);
    }
    
    /*Función principal para resolver el problema del ciclo Hamiltoniano, utiliza backtracking .
    Principalmente utiliza hamCycleRec() para hacer el trabajo. Si existe un ciclo
    Hamiltoniano lo imprime, si no, imprime que no tiene ciclo Hamiltoniano.
    Para encontrar el ciclo Hamiltoniano se crea un arreglo (camino) vacío y
    le añade el vértice 's'. Añade otros vértices iniciando desde '0', checando
    si es adyacente al vértice anterior y que aún no se haya añadido al arreglo.
    Si se encuentra dicho vértice se agrega como parte de la solución.*/
    public String hamiltonian(int[][] matrix, int s) {
        //Si 's' no excede la cantidad de vértices que hay en el grafo
        if (s < V){
            cycle = new int[V];
            for (int i = 0; i < V; i++)
                cycle[i] = -1;
            //Se coloca el vértice 's' en el arreglo
            cycle[0] = s;
            if (hamCycleRec(matrix, cycle, 1) == false)
                return "La gráfica no tiene ciclo hamiltoniano";
            String p = Arrays.toString(cycle);
            p = p.substring(0, p.length() - 1);
            String ret = "La gráfica tiene ciclo hamiltoniano." +
                    " El siguiente es uno de ellos: " + p + ", " +cycle[0] +"]";
            return ret;
        }
        else return "Vértice fuera de límite";
    }
    
    /*Función recursiva para resolver el problema del ciclo Hamiltoniano (Caso base:
    Si todos los vértices están en el ciclo Hamiltoniano)*/
    boolean hamCycleRec(int[][] matrix, int cycle[], int idx) {
        //Último caso
        if (idx == V) {
            //Devuelve si hay una arista del último vértice añadido al primer vértice
            return matrix[cycle[idx-1]][cycle[0]] == 1; 
        }
        //Intenta con diferentes aristas como siguiente candidato para el ciclo Hamiltoniano
        for (int v = 0; v < V; v++) {
            //Checa si el vértice puede añadirse al ciclo Hamiltoniano
            if (canAdd(v, matrix, cycle, idx)) { 
                cycle[idx] = v;
                //Resto del arreglo (recursividad)
                if (hamCycleRec(matrix, cycle, idx + 1) == true) 
                    return true;
                //Si añadir el vértice v no lleva a una solución entonces se quita (Backtrack)
                cycle[idx] = -1;
            }
        }
        //Si ningún vértice es añadido regresa 'false'
        return false;
    }
    
    /*Función que checa si el vértice 'v' puede añadirse en el índice 'idx' en el
    ciclo Hamiltoniano ya construido ('cycle')*/
    boolean canAdd(int v, int[][] matrix, int cycle[], int idx) {
        //Checa si el vértice es adyacente al vértice añadido anteriormente
        if (matrix[cycle[idx - 1]][v] == 0) 
            return false;
        //Checa si el vértice ya se había incluido
        for (int i = 0; i < idx; i++)
            if (cycle[i] == v) 
                return false; 
        return true;
    }

    public void graficar(){
        GraphPicture panel = new GraphPicture(matrix, 1000, 720);
        JFrame app = new JFrame();
//        app.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); //HIDE_ON_CLOSE by default
        app.add(panel);
        app.setSize(1000, 720);
        app.setVisible(true);
    }
}
